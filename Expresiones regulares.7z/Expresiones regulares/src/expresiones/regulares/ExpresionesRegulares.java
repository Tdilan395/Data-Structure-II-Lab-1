/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package expresiones.regulares;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Domain
 */
public class ExpresionesRegulares {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String oneline = "{    \"id\": 1,    \"name\": \"Leanne Graham\",    \"username\": \"Bret\",    \"email\": \"Sincere@april.biz\",    \"address\": {      \"street\": \"Kulas Light\",      \"suite\": \"Apt. 556\",      \"city\": \"Gwenborough\",      \"zipcode\": \"92998-3874\",      \"geo\": {        \"lat\": \"-37.3159\",        \"lng\": \"81.1496\"      }    },    \"phone\": \"1-770-736-8031 x56442\",    \"website\": \"hildegard.org\",    \"company\": {      \"name\": \"Romaguera-Crona\",      \"catchPhrase\": \"Multi-layered client-server neural-net\",      \"bs\": \"harness real-time e-markets\"    }}";
//"{\n" +
//"    \"id\": 1,\n" +
//"    \"name\": \"Leanne Graham\",\n" +
//"    \"username\": \"Bret\",\n" +
//"    \"email\": \"Sincere@april.biz\",\n" +
//"    \"address\": {\n" +
//"      \"street\": \"Kulas Light\",\n" +
//"      \"suite\": \"Apt. 556\",\n" +
//"      \"city\": \"Gwenborough\",\n" +
//"      \"zipcode\": \"92998-3874\",\n" +
//"      \"geo\": {\n" +
//"        \"lat\": \"-37.3159\",\n" +
//"        \"lng\": \"81.1496\"\n" +
//"      }\n" +
//"    },\n" +
//"    \"phone\": \"1-770-736-8031 x56442\",\n" +
//"    \"website\": \"hildegard.org\",\n" +
//"    \"company\": {\n" +
//"      \"name\": \"Romaguera-Crona\",\n" +
//"      \"catchPhrase\": \"Multi-layered client-server neural-net\",\n" +
//"      \"bs\": \"harness real-time e-markets\"\n" +
//"    }\n" +
//"  }";
        //String oneline="\"name\": \"Leanne Graham\",";
            Pattern p = Pattern.compile("\"(\\w+)\": ([[\\w|[\\w +]]\"|\\d]+),");
            Matcher m = p.matcher(oneline);
            if (m.find()) {
                System.out.println("The value of " + m.group(1)+ " is " + m.group(2));
            }
    }
    
}
